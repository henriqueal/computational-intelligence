#include <stdio.h>
#include <stdlib.h>
#include "declarations.h"

#define P 100
#define C 10
#define F 60
#define E 20




struct individuo{
  int cromossomo[10];
  int fitness;
  int cromossomoDecimal;
};

int vetorVisitados[C];
Individuo populacao[160];

int compare (const Individuo * a, const Individuo * b)
{
  return ((b->fitness - a->fitness));
}

int SortearNumero(int divisor){
  return (rand()%divisor);
}

void ZerarVetorVisitados(){
  int i;
  for(i=0;i<10;i++)
    vetorVisitados[i]=0;
}

void GerarPopulacaoInicial(){
  int i,j,numero;
  for(j=0;j<P;j++){
    i=0;
    ZerarVetorVisitados();
    while(1){
      if(i==C) break;
      numero = SortearNumero(10);
      if(vetorVisitados[numero] == 0){
        vetorVisitados[numero] = 1;
        populacao[j].cromossomo[i] = numero;
        i++;
      }
    }
  }
}

int CalcularFit(int n){
  int money; 
  int send;
  int more;

  money = populacao[n].cromossomo[4]*10000;
  money += populacao[n].cromossomo[5]*1000;
  money += populacao[n].cromossomo[2]*100;
  money += populacao[n].cromossomo[1]*10;
  money += populacao[n].cromossomo[7];

  send = populacao[n].cromossomo[0]*1000;
  send += populacao[n].cromossomo[1]*100;
  send += populacao[n].cromossomo[2]*10;
  send += populacao[n].cromossomo[3];

  more = populacao[n].cromossomo[4]*1000;
  more += populacao[n].cromossomo[5]*100;
  more += populacao[n].cromossomo[6]*10;
  more += populacao[n].cromossomo[1];

  return 100000-abs(send+more-money);
}

int MelhoresFit(int n){
  int i;
  int cont=0;
  for(i=0;i<P;i++){
    if(populacao[i].fitness < n) cont++;
  }
  return cont;
}

int MelhoresFit2(int n){
  int i;
  int cont=0;
  for(i=0;i<P;i++){
    if(populacao[i].fitness < n) cont+=populacao[i].fitness;
  }
  return cont;
}

void ExibirPopulacao(int tam){
  int i,j;
  for(i=0;i<tam;i++){
    for(j=0;j<C;j++){
      printf("%d | ", populacao[i].cromossomo[j]);
    }
    printf("%d |", populacao[i].fitness);
    printf("\n");
  }
}

int CalcularDistribuicao(int k){

  int cont=0;
  int i;

  for(i=0;i<100;i++){
    if(populacao[i].cromossomo[4]==k) cont++;
  }
  return cont;
}

int Torneio(int n){
  ////printf("Torneio\n");
  int aux,i;
  int menor = SortearNumero(P);
  ////printf("%d : %d\n",menor, populacao[menor][8]);
  for(i=1;i<n;i++){
     aux = SortearNumero(P);
     ////printf("%d : %d\n",aux, populacao[aux][8]);
     if(populacao[aux].fitness < populacao[menor].fitness){
       menor=aux;
     }
  }
  return menor;
}


void CrossOver(Individuo pai1, Individuo pai2, int i){
  int aux,j,pontoAleatorio;
  int inicioCiclo;
  pontoAleatorio = SortearNumero(C);
  inicioCiclo = pai1.cromossomo[pontoAleatorio];
  //printf("*** Crossing over... ***\n");
  //printf("Pais\n");
  for(j=0;j<C;j++){
    //printf("%d | ",pai1.cromossomo[j]);
  }
  //printf ("\n");
  for(j=0;j<C;j++){
    //printf("%d | ",pai2.cromossomo[j]);
  }
  

  //printf("\nPonto Inicial: %d\n", pontoAleatorio);
  //printf("\nInicio Ciclo: %d\n", inicioCiclo);

  
  while(1){
    aux = pai1.cromossomo[pontoAleatorio];
    pai1.cromossomo[pontoAleatorio] = pai2.cromossomo[pontoAleatorio];
    pai2.cromossomo[pontoAleatorio] = aux;
    
    if(pai1.cromossomo[pontoAleatorio] == inicioCiclo) break;
    
    for(j=0;j<C;j++){
      if(j == pontoAleatorio) continue;
      if(pai1.cromossomo[j] == pai1.cromossomo[pontoAleatorio]) break;
    }
    
    pontoAleatorio = j;
  }
 
  for(j=0;j<C;j++){
    //printf("%d | ",pai1.cromossomo[j]);
  }
  //printf ("\n");
  for(j=0;j<C;j++){
    //printf("%d | ",pai2.cromossomo[j]);
  }
  //printf("\n");

  populacao[100+(2*i)] = pai1;  
  populacao[101+(2*i)] = pai2;  

}


//Estatisticas
int Melhor(int tam){
  int melhor = 100000;
  int i;
  for(i=0;i<tam;i++){
    if(populacao[i].fitness < melhor) melhor = populacao[i].fitness;
  }
  return melhor;
}

float MediaPopulacao(int tam){
  int soma=0;
  int i;
  for(i=0;i<P;i++){
    soma += populacao[i].fitness;
  }
  return (soma*1.0)/(tam*1.0);
}

void Mutacao(){
  int filhoMutante = SortearNumero(60);
  int pos1 = SortearNumero(10);
  int pos2 = SortearNumero(10);

  int aux = populacao[100+filhoMutante].cromossomo[pos1];
  populacao[100+filhoMutante].cromossomo[pos1] = populacao[100+filhoMutante].cromossomo[pos2];
  populacao[100+filhoMutante].cromossomo[pos2] = aux;
}

void Ordena(){
  qsort(populacao, P+F, sizeof(Individuo), (void*)compare);
}

void Elite(){
	qsort(populacao + E, 140, sizeof(Individuo), (void*) compare );
}

