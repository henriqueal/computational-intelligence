#include <stdio.h>
#include <stdlib.h>
#include "funcoes.h"

// 0 1 2 3 4 5 6 7
// S E N D M O R Y

//   S E N D
//   M O R E
// ----------
// M O N E Y


// FUNCOES

// Auxiliares
int compInt (const Individuo *c1, const Individuo *c2){
	return ((c2->fitness - c1->fitness));
}

int ProcuraIndice(int numero, int pai){
	int i;
	for (i=0; i<10; i++){
		if (populacao[pai].vetor[i] == numero)
			return i;
	}
}

void OrdenaPopulacao(int quantidade){
	qsort(populacao,quantidade, sizeof(Individuo),(void*)compInt);
}

void DescartaFilhos(){
	tamanhoPopAtual = TPOP;
}


// Principais
void GeraPopulacao(){
	int i, j, aleatorioUtilizado[10] = {0,0,0,0,0,0,0,0,0,0}, random;

	for(i=0; i<TPOP; i++){
		for(j=0; j<10; j++){
			random = rand()%10;
			while(aleatorioUtilizado[random] == 1){
				random = rand()%10;
			}
			aleatorioUtilizado[random] = 1;

			populacao[i].vetor[j] = random;
/*
			//arquivo
			fprintf(arq,"%d", random);
			if (j != 9)
				fprintf(arq,",");
			else
				fprintf(arq,"-");
*/
		}

		populacao[i].fitness = Fitness(populacao[i]);

		aleatorioUtilizado[0] = 0;
		aleatorioUtilizado[1] = 0;
		aleatorioUtilizado[2] = 0;
		aleatorioUtilizado[3] = 0;
		aleatorioUtilizado[4] = 0;
		aleatorioUtilizado[5] = 0;
		aleatorioUtilizado[6] = 0;
		aleatorioUtilizado[7] = 0;
		aleatorioUtilizado[8] = 0;
		aleatorioUtilizado[9] = 0;
	}
	tamanhoPopAtual = TPOP;

}


void MostraPopulacao(){
	int i, j;

	printf("\n\nPopulacao:\n\n");
	printf("Individuo          Sequencia              Fitness\n\n");

	for(i=0; i<tamanhoPopAtual; i++){
		printf("%d             [",i);
		for(j=0; j<10; j++){
			printf("%d",populacao[i].vetor[j]);
			if (j!=9)
				printf(",");
		}
		printf("]        %d\n", populacao[i].fitness);
	}	
}

void MostraFilhos(){
	int i, j;

	printf("\n\nFilhos:\n\n");
	printf("Individuo          Sequencia              Fitness\n\n");

	for(i=TPOP; i<tamanhoPopAtual; i++){
		printf("%d             [",i);
		for(j=0; j<10; j++){
			printf("%d",populacao[i].vetor[j]);
			if (j!=9)
				printf(",");
		}
		printf("]        %d\n", populacao[i].fitness);
	}	
}

int Fitness(Individuo individuo){
	int send, more, money;
	send = individuo.vetor[0]*(1000) + individuo.vetor[1]*(100) + individuo.vetor[2]*(10) + individuo.vetor[3];
	more = individuo.vetor[4]*(1000) + individuo.vetor[5]*(100) + individuo.vetor[6]*(10) + individuo.vetor[1];
	money = individuo.vetor[4]*(10000) + individuo.vetor[5]*(1000) + individuo.vetor[2]*(100) + individuo.vetor[1]*(10) + individuo.vetor[7];
	

	return (100000 - (abs((send + more) - money)));
}


void CrossOverCiclico(int pai1, int pai2, int filho1){
	short int i, j, inicial, aleatorio, aux, mapafilho2;
	short int mapafilhos[10] = {0,0,0,0,0,0,0,0,0,0};
	int filho2 = filho1 + 1;

	aleatorio = rand()%10;

	inicial = populacao[pai1].vetor[aleatorio];
	i = aleatorio;
	while(populacao[pai2].vetor[i] != inicial){
		j = i;
		i = ProcuraIndice(populacao[pai2].vetor[i], pai1);

		populacao[filho1].vetor[j] = populacao[pai2].vetor[j];
		populacao[filho2].vetor[j] = populacao[pai1].vetor[j];
		mapafilhos[j] = 1;
	}
	populacao[filho1].vetor[i] = populacao[pai2].vetor[i];
	populacao[filho2].vetor[i] = populacao[pai1].vetor[i];
	mapafilhos[i] = 1;

	for(i=0; i<10;i++){
		if (mapafilhos[i] == 0){
			populacao[filho1].vetor[i] = populacao[pai1].vetor[i];
			populacao[filho2].vetor[i] = populacao[pai2].vetor[i];
		}

	}

	//Calculando fitness dos filhos
	populacao[filho1].fitness = Fitness(populacao[filho1]);
	populacao[filho2].fitness = Fitness(populacao[filho2]);
}

int Repetido(int pai, int corte1, int corte2){
	int i, j;
	
	for (i=0; i<10; i++){
		for (j=0; j<10; j++){
			if ((populacao[pai].vetor[i] == populacao[pai].vetor[j]) && (i != j))
				return populacao[pai].vetor[i];
		}
	}
	return -1;
}

void ArrumaCiclo(short int trocas[20]){
	short int i, j, achou=0, trocar, indiceEncontradoInicial, temRepetido=0, vaiTrocar;
/*
	printf("\nVetor de trocas:\n");
	for (i=0; i<20; i++){
		printf("%d ", trocas[i]);
	}
	printf("\n");
*/
	for (i=0; i<20;i++){
		for (j=0; j<20; j++){
			if ((trocas[i] == trocas[j]) && (i != j) && (trocas[j] != -1))
				temRepetido = 1;
		}
	}
	indiceEncontradoInicial = -1;
	trocar = -1;
	while(temRepetido == 1){
		i = 0;
		achou = 0;
		while(i<20){
			if (achou == 0){
				trocar = trocas[i];
				indiceEncontradoInicial = i;
			}
			for (j=0; j<20; j++){
				if ((trocar == trocas[j]) && (i != j) && (trocas[j] != -1)){
					if (j%2 == 0){
						trocar = trocas[j+1];
						trocas[j+1] = -1;
					}else{
						trocar = trocas[j-1];
						trocas[j-1] = -1;
					}
					trocas[j] = -1;
					achou = 1;
					break;
				}
			}
			//printf("\ntrocar=%d", trocar);
			i++;
		}
		if (indiceEncontradoInicial != -1)
			trocas[indiceEncontradoInicial] = trocar;


		temRepetido = 0;
		for (i=0; i<20;i++){
			for (j=0; j<20; j++){
				if ((trocas[i] == trocas[j]) && (i != j) && (trocas[j] != -1) && (trocas[i] != -1)){
					temRepetido = 1;
					//printf("temRepetido");
					break;
				}
			}
			if (temRepetido == 1)
				break;
		}/*
		printf("\nVetor de trocas:\n");
		for (i=0; i<20; i++){
			printf("%d ", trocas[i]);
		}
		printf("\n");
		*/
	
	}
/*
	printf("\nVetor de trocas:\n");
	for (i=0; i<20; i++){
		printf("%d ", trocas[i]);
	}
	printf("\n");
*/
}



int substituirPor(int chave, short int vetor[20]){
	int i=0;
	for(i=0; i<20 ;i++){
		if(vetor[i] == chave){
			if(i%2==0){
				return vetor[i+1];
			}
			return vetor[i-1];
		}
	}
}

void Elite(){
	printf("dDENTRO ELITE ANTES:");
	MostraPopulacao();
	qsort(populacao+PELITE,140, sizeof(Individuo),(void*)compInt);
	printf("dDENTRO ELITE DEPOIS:");
	MostraPopulacao();
}


void CrossOverPMX(int pai1, int pai2, int filho1){
	short int i, j, k, inicial, aleatorio, aux, mapafilho2, corte1, corte2;
	short int mapafilhos[10] = {0,0,0,0,0,0,0,0,0,0};
	short int filho2 = filho1 + 1;
	short int trocas[20] = {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
	short int valorRepetido;
	short int achou=0;
	short int trocar;

	aleatorio = rand()%10;
	
	corte1 = rand()%10;
	corte2 = rand()%10;
	while(corte2 < corte1)
		corte2 = rand()%10;
 
	//printf("\ncorte1=%d e corte2=%d\n", corte1, corte2);

	// Copia os pais para os filhos
	for (i=0; i<10; i++){
		populacao[filho1].vetor[i] = populacao[pai1].vetor[i];
		populacao[filho2].vetor[i] = populacao[pai2].vetor[i];
	}


	k=0;
	for (i=corte1; i<corte2; i++){
		trocas[k] = populacao[filho1].vetor[i];
		trocas[k+1] = populacao[filho2].vetor[i];
		aux = populacao[filho1].vetor[i];
		populacao[filho1].vetor[i] = populacao[filho2].vetor[i];
		populacao[filho2].vetor[i] = aux;
		k += 2;
	}

	ArrumaCiclo(trocas);
/*
	printf("\nvetor de trocas:\n");
	for (i=0; i<20; i++){
		printf("%d ", trocas[i]);
	}
	printf("\n");
*/
    while(1){
		valorRepetido = Repetido(filho1, corte1, corte2);
		//printf("valorRepetido =%d\n", valorRepetido);

		if (valorRepetido == -1)
			break;

		for(i=0; i<10; i++){
			if(i>=corte1 && i<corte2)
				continue;

			if(populacao[filho1].vetor[i] == valorRepetido){
				populacao[filho1].vetor[i] = substituirPor(valorRepetido, trocas);
			}

		}    	
    }	

    while(1){
		valorRepetido = Repetido(filho2, corte1, corte2);

		if (valorRepetido == -1)
			break;

		for(i=0; i<10; i++){
			if(i>=corte1 && i<corte2)
				continue;

			if(populacao[filho2].vetor[i] == valorRepetido){
				populacao[filho2].vetor[i] = substituirPor(valorRepetido, trocas);
			}

		}    	
    }	

    //Calculando fitness dos filhos
	populacao[filho1].fitness = Fitness(populacao[filho1]);
	populacao[filho2].fitness = Fitness(populacao[filho2]);

//    printf("CrossoverPMX feito.\n");


}






void ReproduzNovaGeracao(){
	int i, j, quant_cross, quant_mut, pai1, pai2;

	quant_cross = ((float)PCROSS/100)*TPOP;
	quant_mut = ((float)PMUT/100)*TPOP;

	//tamanhoPopAtual = TPOP;

//	printf("quantcross=%d", quant_cross);

	for(i=0; i<(quant_cross/2); i++){
		pai1 = Tour(TOUR);
		pai2 = Tour(TOUR);
		//pai1 = Roleta();
		//pai2 = Roleta();
/*
		printf("iteracao %d\n", i);
		printf("pai1=%d, ",pai1);
		printf("pai2=%d\n\n",pai2);
*/
		//CrossOverCiclico(pai1,pai2,TPOP+(2*i));
		CrossOverPMX(pai1,pai2,TPOP+(2*i));
		tamanhoPopAtual += 2;
	}

	FazMutacao();
//	OrdenaPopulacao(tamanhoPopAtual);

	Elite();
	DescartaFilhos();
	geracao++;

}

void FazMutacao(){
	int i,j, filho_sorteado, pos1, pos2, aux;
	// Sorteando somente os filhos
	filho_sorteado = (rand()%(tamanhoPopAtual - TPOP)) + TPOP;
	// Sorteando as posicoes para trocar no vetor do filho
	pos1 = rand()%10;
	pos2 = rand()%10;

	//printf("filho sorteado: %d  -  pos1:%d  -  pos2:%d\n", filho_sorteado, pos1, pos2);

	aux = populacao[filho_sorteado].vetor[pos1];
	populacao[filho_sorteado].vetor[pos1] = populacao[filho_sorteado].vetor[pos2];
	populacao[filho_sorteado].vetor[pos2] = aux;
}

// Retorna o indice do individuo sorteado
int Tour(int quant){
	int i, j, aleatorio, melhor_aptidao, melhor_aptidao_indice;
	short int *escolhidos, encontrou;

	if (quant > TPOP)
		return -1;

	escolhidos = (short int*) malloc (quant*sizeof(short int));
	for(i=0; i<quant; i++)
		escolhidos[i] = -1;

	encontrou = 0;

	// Preenchendo o vetor de escolhidos	
	for(i=0; i<quant; i++){
/*   Sorteio sem repeticoes
		do{
			aleatorio = rand()%TPOP;
			for (j=0; j<quant; j++){
				if (escolhidos[j] == aleatorio){
					encontrou = 1;
					break;
				}
			}
			if (j == quant)
				encontrou = 0;

		}while(encontrou == 1);
*/
		aleatorio = rand()%TPOP;
		escolhidos[i] = aleatorio;
	}

	// Pegando o que tem a maior aptidao
	melhor_aptidao = populacao[escolhidos[0]].fitness;
	melhor_aptidao_indice = escolhidos[0];
	for(i=0; i<quant; i++){
		if (populacao[escolhidos[i]].fitness > melhor_aptidao){
			melhor_aptidao = populacao[escolhidos[i]].fitness;
			melhor_aptidao_indice = escolhidos[i];
		}
	}
/*
	// DEBUG: Mostrando os escolhidos, e o melhor dentre eles
	printf("\n---------Escolhidos pelo Tour(%d):-------------------\n\n", quant);
	for (i=0; i<quant; i++){
		printf("Individuo %d - fitness= %d\n", escolhidos[i], populacao[escolhidos[i]].fitness);
	}

	printf("\nMelhor escolhido dentre os %d: Individuo %d.\n", quant, melhor_aptidao_indice);
	printf("\n----------------------------------------------------\n");
*/

	return melhor_aptidao_indice;
}

// Retorna o indice do individuo sorteado
int Roleta(){
	long int maximo_roleta=0, random;
	int *roleta, i;

	for (i=0; i<TPOP; i++){
		maximo_roleta += populacao[i].fitness;
	}

	
	roleta = (int*) malloc(TPOP*sizeof(int));
	random = rand()%maximo_roleta;

	roleta[0] = populacao[0].fitness;
	for (i=1; i<TPOP; i++){
		roleta[i] = roleta[i-1] + populacao[i].fitness;
	}

	i=0;
	while(random > roleta[i]){
		i++;
	}
	if (random == roleta[i])
		return i;
	else{
		if (i==0)
			return 0;
		else
			return i-1;
	}

}

void MostraMelhorIndividuo(){
	int i, melhor_fitness, melhor_indice;

	melhor_fitness = populacao[0].fitness;
	melhor_indice = 0;
	for (i=0; i<TPOP; i++){
		if (populacao[i].fitness > melhor_fitness){
			melhor_fitness = populacao[i].fitness;
			melhor_indice = i;
		}
	}
	printf("\nO melhor individuo e:\n");
	printf("            S E N D M O R Y\n");
	printf("Sequencia: [");
	for(i=0; i<8; i++){
		printf("%d",populacao[melhor_indice].vetor[i]);
		if (i!=7)
			printf(",");
	}
	printf("]\nFitness: %d\n", populacao[melhor_indice].fitness);
}

void SomaResultados(){
	int i, ntop, quant_m0, quant_m1;
	double media_ntop_fit, media_todos_fit;

	media_todos_fit = 0;
	ntop=0;
	media_ntop_fit = 0;
	quant_m0 = 0;
	quant_m1 = 0;
	for (i=0; i<TPOP; i++){
		media_todos_fit += populacao[i].fitness;
		if (populacao[i].fitness > 99900){
			media_ntop_fit += populacao[i].fitness;
			ntop++;
		}
		if (populacao[i].vetor[4] == 0)
			quant_m0 ++;
		if (populacao[i].vetor[4] == 1)
			quant_m1 ++;
	}
	media_ntop_fit = media_ntop_fit / ntop;
	media_todos_fit = media_todos_fit / TPOP;

	resultados[0] += populacao[0].fitness;
	resultados[1] += ntop;	
	resultados[2] += media_todos_fit;
	resultados[3] += media_ntop_fit;
	resultados[4] += quant_m0;
	resultados[5] += quant_m1;
}

void ZeraResultados(){
	resultados[0] = 0;
	resultados[1] = 0;	
	resultados[2] = 0;
	resultados[3] = 0;
	resultados[4] = 0;
	resultados[5] = 0;
}

void FazMediaResultados(){
	resultados[0] = resultados[0] / 51;
	resultados[1] = resultados[1] / 51;
	resultados[2] = resultados[2] / 51;
	resultados[3] = resultados[3] / 51;
	resultados[4] = resultados[4] / 51;
	resultados[5] = resultados[5] / 51;
}

void GravaResultados(){
	FILE *arq = fopen("resultados", "a+");

	fprintf(arq, "Geracao numero %d\n", geracao);
	fprintf(arq, "Melhor individuo: fitness=%.4lf\n", resultados[0]);
	fprintf(arq, "Numero de individuos fitness<100  (N-top): %.4lf\n", resultados[1]);
	fprintf(arq, "Media do fitness de todos: %.4lf\n", resultados[2]);
	fprintf(arq, "Media do fitness dos N-top: %.4lf\n", resultados[3]);
	fprintf(arq, "Numero de individuos com M=0: %.4lf\n", resultados[4]);
	fprintf(arq, "Numero de individuos com M=1: %.4lf\n\n", resultados[5]);
	ZeraResultados();
	fclose(arq);
}