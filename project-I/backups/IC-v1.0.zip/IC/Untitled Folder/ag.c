#include <stdio.h>
#include <stdlib.h>
#include "funcoes.h"

// 0 1 2 3 4 5 6 7
// S E N D M O R Y

// 0 4 6 8 4   - conta
// 4 5 2 1 7

//   S E N D
//   M O R E
// ----------
// M O N E Y

void main(){
	int i;
	srand(time(NULL));

	system("clear");
	tamanhoPopAtual = 0;
	populacao = (Individuo*) malloc((int)(TPOP + ((float)PCROSS/100)*TPOP)*sizeof(Individuo));
	ZeraResultados();




	GeraPopulacao();
	OrdenaPopulacao(tamanhoPopAtual);

printf("ANTES:\n");
	MostraPopulacao();

	ReproduzNovaGeracao();
	geracao = 1;
printf("DEPOIS:\n");
	MostraPopulacao();


	SomaResultados();
	GravaResultados();

	for (i=0; i<50; i++){
		ReproduzNovaGeracao();
		SomaResultados();
	}

/*
	ZeraResultados();
	SomaResultados();
*/
/*
	MostraPopulacao();	

	FazMediaResultados();
	GravaResultados();
*/
}