// ESTRUTURA DO INDIVIDUO
typedef struct individuo{
	short unsigned int vetor[10];
	unsigned int fitness;
}Individuo;


// DEFINICOES
#define TPOP 100
#define PCROSS 60
#define PMUT 1
#define PELITE 20
#define TOUR 3

// Variaveis globais
Individuo *populacao;
int tamanhoPopAtual;
double resultados[6];
int geracao;

// vetor "resultados":
//       0            1               2                           3                    4
// [Fitness melhor, n-top, media de todos fitness, media dos fitness dos n-top, #indiv m=0/m=1]


// typedef da populacao
typedef struct populacao Populacao;


// FUNCOES

void GeraPopulacao();
void MostraPopulacao();
void MostraFilhos();
void ReproduzNovaGeracao();
int ProcuraIndice(int numero, int pai);
void CrossOverCiclico(int pai1, int pai2, int filho1);
void MostraMelhorIndividuo();
int Tour(int quant);
int compInt (const Individuo *c1, const Individuo *c2);
void OrdenaPopulacao();
void DescartaFilhos();
void SomaResultados();
void FazMediaResultados();
void GravaResultados();
void ZeraResultados();
void FazMutacao();
int Repetido(int pai, int corte1, int corte2);
void ArrumaCiclo();
void CrossOverPMX(int pai1, int pai2, int filho1);
int substituirPor(int chave, short int vetor[20]);
void Elite();

// Populacao (lista)
/*
Populacao *CriaPopulacao();
Populacao *InsereIndividuo(Populacao *P, Individuo individuoInserido);
Populacao *GeraPopulacao(Populacao p);
Populacao *CrossOver(Populacao p);
*/

int Fitness(Individuo individuo);

