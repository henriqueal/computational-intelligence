#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include "functions.c"

#define T 3

int main(){
  //sendmory
  //01234567
  
  int semente = 50;
  int i,j,k,cont=0;
  int numero, qtdM0=0, qtdM1=0, qtdM02=0, qtdM12=0;
  long long int sumFitPop0=0, sumBestFitPop0=0, sumNroIndUnder100=0, sumFitIndUnder100=0;
  long long int sumFitPop02=0, sumBestFitPop02=0, sumNroIndUnder1002=0, sumFitIndUnder1002=0;
  Individuo pai1,pai2;
  

  srand(time(NULL));

  for(k=0;k<1000;k++){
  for(semente =1;semente<=50;semente++){ 
  //srand(semente);
  if(semente==1){
  GerarPopulacaoInicial();
  }
  //Calcular Fit
  for(j=0;j<P;j++)
    populacao[j].fitness=CalcularFit(j);

	Ordena(P);


  //CrossOver + Torneio
  for(i=0;i<F/2;i++){
    //printf("%d\n",Torneio(TORNEIO));
    pai1 = populacao[Torneio(T)];
    pai2 = populacao[Torneio(T)];
    CrossOver(pai1,pai2,i);
  }

	/*for(i=0;i<F/2;i++){
    //printf("%d\n",Torneio(TORNEIO));
    CrossOverPMX(Torneio(T),Torneio(T),i);
  }*/

  Mutacao();

  //Calcular Fit
  for(j=P;j<P+F;j++)
    populacao[j].fitness=CalcularFit(j);	

  Ordena(P+F);
  //Elite();

  //ExibirPopulacao(P+F);

	//printf("\n\n\n\n");


	}

  //printf("K:%d\n",k);

  if(populacao[0].fitness == 100000)
	cont++;


}
/*
  qtdM02 += CalcularDistribuicao(0);
  qtdM12 += CalcularDistribuicao(1);

  for(i=0;i<P;i++){
    sumFitPop02 += populacao[i].fitness;
  }

  sumBestFitPop02 += Melhor(P);
  sumNroIndUnder1002 += MelhoresFit(100);
  sumFitIndUnder1002 += MelhoresFit2(100);

  //printf("==============================================================\n");

  }
 
  printf("***Estatisticas***\n"); 
  printf("Media fitness: %.2f\n",sumFitPop0/5000.0);
  printf("Melhor fitness %.2f\n",sumBestFitPop0/50.0);
  printf("Nro individuos < 100: %.2f\n",sumNroIndUnder100/50.0);
  printf("Media individuos < 100: %.2f\n",sumFitIndUnder100*1.0/sumNroIndUnder100);
  printf("Nro ind com M=0: %.2f\n",qtdM0/50.0);
  printf("Nro ind com M=1: %.2f\n",qtdM1/50.0);
  printf("-------------------------\n");

  
  //printf("***Estatisticas***\n"); 
  printf("Media fitness: %.2f\n",sumFitPop02/5000.0);
  printf("Melhor fitness %.2f\n",sumBestFitPop02/50.0);
  printf("Nro individuos < 100: %.2f\n",sumNroIndUnder1002/50.0);
  printf("Media individuos < 100: %.2f\n",sumFitIndUnder1002*1.0/sumNroIndUnder1002);
  printf("Nro ind com M=0: %.2f\n",qtdM02/50.0);
  printf("Nro ind com M=1: %.2f\n",qtdM12/50.0);
  //printf("-------------------------\n");

*/


  printf("\nCont:%d\n",cont);
  return 0;


}
