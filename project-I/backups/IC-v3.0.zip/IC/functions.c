#include <stdio.h>
#include <stdlib.h>
#include "declarations.h"

#define P 100
#define C 10
#define F 60
#define E 20
#define M 10




struct individuo{
  int cromossomo[10];
  int fitness;
  int cromossomoDecimal;
};

int vetorVisitados[C];
Individuo populacao[160];

int compare (const Individuo * a, const Individuo * b)
{
  return ((b->fitness - a->fitness));
}

int SortearNumero(int divisor){
  return (rand()%divisor);
}

void ZerarVetorVisitados(){
  int i;
  for(i=0;i<10;i++)
    vetorVisitados[i]=0;
}

void GerarPopulacaoInicial(){
  int i,j,numero;
  for(j=0;j<P;j++){
    i=0;
    ZerarVetorVisitados();
    while(1){
      if(i==C) break;
      numero = SortearNumero(10);
      if(vetorVisitados[numero] == 0){
        vetorVisitados[numero] = 1;
        populacao[j].cromossomo[i] = numero;
        i++;
      }
    }
  }
}

int CalcularFit(int n){
  int money; 
  int send;
  int more;

  money = populacao[n].cromossomo[4]*10000;
  money += populacao[n].cromossomo[5]*1000;
  money += populacao[n].cromossomo[2]*100;
  money += populacao[n].cromossomo[1]*10;
  money += populacao[n].cromossomo[7];

  send = populacao[n].cromossomo[0]*1000;
  send += populacao[n].cromossomo[1]*100;
  send += populacao[n].cromossomo[2]*10;
  send += populacao[n].cromossomo[3];

  more = populacao[n].cromossomo[4]*1000;
  more += populacao[n].cromossomo[5]*100;
  more += populacao[n].cromossomo[6]*10;
  more += populacao[n].cromossomo[1];

  return 100000-abs(send+more-money);
}

int MelhoresFit(int n){
  int i;
  int cont=0;
  for(i=0;i<P;i++){
    if(populacao[i].fitness < n) cont++;
  }
  return cont;
}

int MelhoresFit2(int n){
  int i;
  int cont=0;
  for(i=0;i<P;i++){
    if(populacao[i].fitness < n) cont+=populacao[i].fitness;
  }
  return cont;
}

void ExibirPopulacao(int tam){
  int i,j;
  for(i=0;i<tam;i++){
    for(j=0;j<C;j++){
      printf("%d | ", populacao[i].cromossomo[j]);
    }
    printf("%d |", populacao[i].fitness);
    printf("\n");
  }
}

int CalcularDistribuicao(int k){

  int cont=0;
  int i;

  for(i=0;i<100;i++){
    if(populacao[i].cromossomo[4]==k) cont++;
  }
  return cont;
}

int Torneio(int n){
  ////printf("Torneio\n");
  int aux,i;
  int melhor = SortearNumero(P);
  ////printf("%d : %d\n",menor, populacao[menor][8]);
  for(i=1;i<n;i++){
     aux = SortearNumero(P);
     ////printf("%d : %d\n",aux, populacao[aux][8]);
     if(populacao[aux].fitness > populacao[melhor].fitness){
       melhor=aux;
     }
  }
  return melhor;
}

int Roleta(){
	long int maximo_roleta=0, random;
	int *roleta, i;

	for (i=0; i<P; i++){
		maximo_roleta += populacao[i].fitness;
	}

	
	roleta = (int*) malloc(P*sizeof(int));
	random = rand()%maximo_roleta;

	roleta[0] = populacao[0].fitness;
	for (i=1; i<P; i++){
		roleta[i] = roleta[i-1] + populacao[i].fitness;
	}

	i=0;
	while(random > roleta[i]){
		i++;
	}
	if (random == roleta[i])
		return i;
	else{
		if (i==0)
			return 0;
		else
			return i-1;
	}

}


void CrossOver(Individuo pai1, Individuo pai2, int i){
  int aux,j,pontoAleatorio;
  int inicioCiclo;
  pontoAleatorio = SortearNumero(C);
  inicioCiclo = pai1.cromossomo[pontoAleatorio];

  while(1){
    aux = pai1.cromossomo[pontoAleatorio];
    pai1.cromossomo[pontoAleatorio] = pai2.cromossomo[pontoAleatorio];
    pai2.cromossomo[pontoAleatorio] = aux;
    
    if(pai1.cromossomo[pontoAleatorio] == inicioCiclo) break;
    
    for(j=0;j<C;j++){
      if(j == pontoAleatorio) continue;
      if(pai1.cromossomo[j] == pai1.cromossomo[pontoAleatorio]) break;
    }
    
    pontoAleatorio = j;
  }


  populacao[100+(2*i)] = pai1;  
  populacao[101+(2*i)] = pai2;  

}


//Estatisticas
int Melhor(int tam){
  int melhor = 100000;
  int i;
  for(i=0;i<tam;i++){
    if(populacao[i].fitness < melhor) melhor = populacao[i].fitness;
  }
  return melhor;
}

float MediaPopulacao(int tam){
  int soma=0;
  int i;
  for(i=0;i<P;i++){
    soma += populacao[i].fitness;
  }
  return (soma*1.0)/(tam*1.0);
}

void Mutacao(){
  int filhoMutante, pos1, pos2,i;

  for(i=0;i<M;i++){
	  filhoMutante = SortearNumero(60);
	  pos1 = SortearNumero(10);
	  pos2 = SortearNumero(10);

	  int aux = populacao[100+filhoMutante].cromossomo[pos1];
	  populacao[100+filhoMutante].cromossomo[pos1] = populacao[100+filhoMutante].cromossomo[pos2];
	  populacao[100+filhoMutante].cromossomo[pos2] = aux;
  }
}

void Ordena(int a){
  qsort(populacao, a, sizeof(Individuo), (void*)compare);
}

void Elite(){
	qsort(populacao + E, 140, sizeof(Individuo), (void*) compare );
}

int Repetido(int pai, int corte1, int corte2){
	int i, j;
	
	for (i=0; i<10; i++){
		for (j=0; j<10; j++){
			if ((populacao[pai].cromossomo[i] == populacao[pai].cromossomo[j]) && (i != j))
				return populacao[pai].cromossomo[i];
		}
	}
	return -1;
}

void ArrumaCiclo(short int trocas[20]){
	short int i, j, achou=0, trocar, indiceEncontradoInicial, temRepetido=0, vaiTrocar;
/*
	printf("\nVetor de trocas:\n");
	for (i=0; i<20; i++){
		printf("%d ", trocas[i]);
	}
	printf("\n");
*/
	for (i=0; i<20;i++){
		for (j=0; j<20; j++){
			if ((trocas[i] == trocas[j]) && (i != j) && (trocas[j] != -1))
				temRepetido = 1;
		}
	}
	indiceEncontradoInicial = -1;
	trocar = -1;
	while(temRepetido == 1){
		i = 0;
		achou = 0;
		while(i<20){
			if (achou == 0){
				trocar = trocas[i];
				indiceEncontradoInicial = i;
			}
			for (j=0; j<20; j++){
				if ((trocar == trocas[j]) && (i != j) && (trocas[j] != -1)){
					if (j%2 == 0){
						trocar = trocas[j+1];
						trocas[j+1] = -1;
					}else{
						trocar = trocas[j-1];
						trocas[j-1] = -1;
					}
					trocas[j] = -1;
					achou = 1;
					break;
				}
			}
			//printf("\ntrocar=%d", trocar);
			i++;
		}
		if (indiceEncontradoInicial != -1)
			trocas[indiceEncontradoInicial] = trocar;


		temRepetido = 0;
		for (i=0; i<20;i++){
			for (j=0; j<20; j++){
				if ((trocas[i] == trocas[j]) && (i != j) && (trocas[j] != -1) && (trocas[i] != -1)){
					temRepetido = 1;
					//printf("temRepetido");
					break;
				}
			}
			if (temRepetido == 1)
				break;
		}/*
		printf("\nVetor de trocas:\n");
		for (i=0; i<20; i++){
			printf("%d ", trocas[i]);
		}
		printf("\n");
		*/
	
	}
/*
	printf("\nVetor de trocas:\n");
	for (i=0; i<20; i++){
		printf("%d ", trocas[i]);
	}
	printf("\n");
*/
}



int substituirPor(int chave, short int vetor[20]){
	int i=0;
	for(i=0; i<20 ;i++){
		if(vetor[i] == chave){
			if(i%2==0){
				return vetor[i+1];
			}
			return vetor[i-1];
		}
	}
}

void CrossOverPMX(int pai1, int pai2, int filho1){
  filho1*=2;
	filho1+=100;
	short int i, j, k, inicial, aleatorio, aux, mapafilho2, corte1, corte2;
	short int mapafilhos[10] = {0,0,0,0,0,0,0,0,0,0};
	short int filho2 = filho1 + 1;
	short int trocas[20] = {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
	short int valorRepetido;
	short int achou=0;
	short int trocar;

	aleatorio = rand()%10;
	
	corte1 = rand()%10;
	corte2 = rand()%10;
	while(corte2 < corte1)
		corte2 = rand()%10;
 
	//printf("\ncorte1=%d e corte2=%d\n", corte1, corte2);

	// Copia os pais para os filhos
	for (i=0; i<10; i++){
		populacao[filho1].cromossomo[i] = populacao[pai1].cromossomo[i];
		populacao[filho2].cromossomo[i] = populacao[pai2].cromossomo[i];
	}


	k=0;
	for (i=corte1; i<corte2; i++){
		trocas[k] = populacao[filho1].cromossomo[i];
		trocas[k+1] = populacao[filho2].cromossomo[i];
		aux = populacao[filho1].cromossomo[i];
		populacao[filho1].cromossomo[i] = populacao[filho2].cromossomo[i];
		populacao[filho2].cromossomo[i] = aux;
		k += 2;
	}

	ArrumaCiclo(trocas);

    while(1){
		valorRepetido = Repetido(filho1, corte1, corte2);
		//printf("valorRepetido =%d\n", valorRepetido);

		if (valorRepetido == -1)
			break;

		for(i=0; i<10; i++){
			if(i>=corte1 && i<corte2)
				continue;

			if(populacao[filho1].cromossomo[i] == valorRepetido){
				populacao[filho1].cromossomo[i] = substituirPor(valorRepetido, trocas);
			}

		}    	
    }	

    while(1){
		valorRepetido = Repetido(filho2, corte1, corte2);

		if (valorRepetido == -1)
			break;

		for(i=0; i<10; i++){
			if(i>=corte1 && i<corte2)
				continue;

			if(populacao[filho2].cromossomo[i] == valorRepetido){
				populacao[filho2].cromossomo[i] = substituirPor(valorRepetido, trocas);
			}

		}    	
    }	
}
